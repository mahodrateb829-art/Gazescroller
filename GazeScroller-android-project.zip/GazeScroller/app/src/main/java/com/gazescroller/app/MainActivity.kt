package com.gazescroller.app

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.gazescroller.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // بنستخدمها عشان نميّز إذا كنا إحنا اللي فتحنا شاشة إعدادات إمكانية الوصول
    // (زر "فتح إعدادات إمكانية الوصول")، عشان لما المستخدم يرجع من هناك
    // نكمل الرحلة أوتوماتيكيًا (نطلب إذن الكاميرا ثم نفتح إنستغرام) من غير
    // ما يحتاج يضغط أي زر تاني بنفسه
    private var waitingForAccessibilitySettings = false

    // لما تصير true، معناها الخدمة اشتغلت وعم ننتظر بس المعايرة تخلص
    // عشان نفتح إنستغرام أوتوماتيكيًا (بدل ما نفتحه فورًا ونعاير جواه)
    private var waitingForCalibrationToOpenInstagram = false

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startServiceAndOpenInstagram()
        } else {
            binding.statusText.text = "لازم توافق على إذن الكاميرا عشان التتبع يشتغل."
        }
    }

    // أندرويد 13+: بدون هاد الإذن إشعار الخدمة (وزر "إيقاف" اللي فيه) ما بيظهر
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* ما في شي نعمله: التتبع بيشتغل سواء وافق أو لأ */ }
    private var askedNotificationPermission = false

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && !askedNotificationPermission &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotificationPermission = true
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        registerLiveUpdates()
        showLastCrashIfAny()

        // الزر الرئيسي الوحيد اللي المستخدم محتاجه فعليًا: بيتولى كل الخطوات
        // (تفعيل إمكانية الوصول لو لسه مش مفعّلة -> إذن الكاميرا لو لسه مش
        // معطى -> تشغيل التتبع -> فتح إنستغرام) بضغطة واحدة، ومن غير ما
        // يعيد أي خطوة سبق وخلّصها قبل هيك
        binding.btnMainAction.setOnClickListener { proceed() }

        // زرار صغير احتياطي بس، مش جزء من المسار الأساسي
        binding.btnRecalibrate.setOnClickListener {
            val service = GazeCameraService.instance
            if (service == null) {
                binding.statusText.text = "شغّل التتبع الأول قبل ما تعاير."
            } else {
                service.recalibrate()
                binding.statusText.text = "خلّي راسك بوضعيتك المريحة العادية ٢-٣ ثواني... عم نعاير."
            }
        }

        // أول ما التطبيق يفتح: لو كل الأذونات أصلاً معطاة من مرة سابقة، ما
        // في داعي نعرض أي خطوات أو ننتظر ضغطة المستخدم — نفوت فورًا على
        // إنستغرام مباشرة
        if (isFullyAuthorized()) {
            proceed()
        } else {
            updateReadinessUi()
        }
    }

    override fun onResume() {
        super.onResume()
        // لو كنا مستنيين رجوع المستخدم من شاشة إعدادات إمكانية الوصول،
        // كمّل الرحلة أوتوماتيكيًا من غير ما يحتاج يضغط أي حاجة تاني
        if (waitingForAccessibilitySettings && isAccessibilityServiceEnabled()) {
            waitingForAccessibilitySettings = false
            proceed()
        } else if (!waitingForAccessibilitySettings && !waitingForCalibrationToOpenInstagram) {
            // ما منمسح رسالة المعايرة/الأخطاء وإحنا لسه عم نعاير
            updateReadinessUi()
        }
    }

    /** بيتولى كل خطوة ناقصة بالترتيب، وبيتخطى أي خطوة خلصانة أصلاً */
    private fun proceed() {
        if (!isAccessibilityServiceEnabled()) {
            waitingForAccessibilitySettings = true
            binding.statusText.text = "فعّل \"مرّر بميل رأسك\" من قائمة إمكانية الوصول..."
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            return
        }

        startServiceAndOpenInstagram()
    }

    private fun startServiceAndOpenInstagram() {
        askNotificationPermissionIfNeeded()
        val intent = Intent(this, GazeCameraService::class.java)
        ContextCompat.startForegroundService(this, intent)

        val launchIntent = packageManager.getLaunchIntentForPackage("com.instagram.android")
        if (launchIntent == null) {
            binding.statusText.text = "إنستغرام مش متثبّت على الجهاز."
            return
        }

        // ما منفتح إنستغرام فورًا — منستنى المعايرة تخلص الأول (onPitchUpdate
        // تحت رح تفتحه أوتوماتيكيًا أول ما baseline يتحدد). هيك المستخدم بيشوف
        // تقدّم المعايرة بوضوح جوا شاشة التطبيق قبل ما ينتقل، بدل ما يعاير
        // وهو جوا إنستغرام من غير ما يعرف الوضع وصل لوين
        pendingInstagramLaunchIntent = launchIntent
        waitingForCalibrationToOpenInstagram = true
        binding.statusText.text = "🎯 عم نعاير... خلّي راسك بوضعيتك المريحة، وبنفتح إنستغرام أوتوماتيكيًا أول ما تخلص"
    }

    private var pendingInstagramLaunchIntent: Intent? = null

    private fun isAccessibilityServiceEnabled(): Boolean {
        // بنقارن ComponentName بدل نص حرفي: بعض الأجهزة بتخزّن الاسم المختصر
        // (com.gazescroller.app/.GazeAccessibilityService) فكانت المقارنة النصية بتفشل
        val expected = ComponentName(this, GazeAccessibilityService::class.java)
        val enabledServices = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        for (service in splitter) {
            if (ComponentName.unflattenFromString(service) == expected) return true
        }
        return false
    }

    private fun isFullyAuthorized(): Boolean {
        return isAccessibilityServiceEnabled() &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
    }

    /**
     * لو التطبيق كرّش قبل هيك، بيعرض نص الخطأ الكامل بنافذة عشان تقدر تنسخه
     * وترسله. بعد ما يتعرض، بينمسح عشان ما يتكرر عرضه كل مرة.
     */
    private fun showLastCrashIfAny() {
        val crashText = CrashLogger.readLastCrash(this) ?: return
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("صار كراش قبل هيك — هاد نص الخطأ")
            .setMessage(crashText)
            .setPositiveButton("نسخ الخطأ") { _, _ ->
                val clipboard = getSystemService(android.content.ClipboardManager::class.java)
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("crash log", crashText))
                CrashLogger.clearLastCrash(this)
            }
            .setNegativeButton("إغلاق") { _, _ ->
                CrashLogger.clearLastCrash(this)
            }
            .setCancelable(false)
            .show()
    }

    /** بيحدّث نص الحالة والزر الرئيسي حسب وين المستخدم واصل بالإعداد */
    private fun updateReadinessUi() {
        binding.statusText.text = when {
            !isAccessibilityServiceEnabled() ->
                "اضغط \"ابدأ\" وفعّل إمكانية الوصول — خطوة تصير مرة واحدة بس."
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED ->
                "خطوة أخيرة: امنح إذن الكاميرا وبنفتح إنستغرام على طول."
            else -> "كل شي جاهز ✅"
        }
    }

    /**
     * تسجيل مستمعي التحديثات اللحظية من GazeCameraService.
     * بنستدعيها من onCreate عشان تشتغل حتى لو الخدمة كانت أصلاً شغّالة
     * قبل ما الأكتيفيتي دي تتفتح (بدل ما تنحصر جوه startServiceAndOpenInstagram بس).
     */
    private fun registerLiveUpdates() {
        GazeCameraService.onPitchUpdate = { rawPitch, baseline, relativePitch, calibrationProgress ->
            runOnUiThread {
                val connected = if (GazeAccessibilityService.instance != null) "متصلة ✅" else "غير متصلة ❌"
                if (baseline == null) {
                    val progressText = calibrationProgress?.let { " ($it)" } ?: ""
                    binding.statusText.text =
                        "🎯 عم نعاير$progressText... خلّي راسك بوضعيتك المريحة (زاوية خام: ${"%.1f".format(rawPitch)}°)"
                } else {
                    binding.statusText.text =
                        "الانحراف عن وضعية الراحة: ${"%.1f".format(relativePitch ?: 0f)}° (العتبة ±12°) — إمكانية الوصول: $connected"

                    // المعايرة خلصت (baseline صار موجود): لو كنا مستنيينها
                    // عشان نفتح إنستغرام، هلق الوقت المناسب
                    if (waitingForCalibrationToOpenInstagram) {
                        waitingForCalibrationToOpenInstagram = false
                        val launchIntent = pendingInstagramLaunchIntent
                        pendingInstagramLaunchIntent = null
                        if (launchIntent != null) {
                            binding.statusText.text = "تمت المعايرة ✅ — جاري فتح إنستغرام، ميّل راسك للتمرير 👁️"
                            startActivity(launchIntent)
                        }
                    }
                }
            }
        }
        GazeCameraService.onNoFaceDetected = {
            runOnUiThread {
                binding.statusText.text = "مش شايف وش! قرّب من الكاميرا وتأكد من الإضاءة."
            }
        }
        GazeCameraService.onError = { message ->
            runOnUiThread {
                binding.statusText.text = message
            }
        }
        GazeCameraService.onBlinkDetected = {
            runOnUiThread {
                binding.statusText.text = "❤️ غمزة! اتعمل لايك"
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        GazeCameraService.onPitchUpdate = null
        GazeCameraService.onNoFaceDetected = null
        GazeCameraService.onError = null
        GazeCameraService.onBlinkDetected = null
    }
}

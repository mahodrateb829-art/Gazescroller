package com.gazescroller.app

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ماسك انهيارات عام: بيلقط أي استثناء غير معالج بأي مكان بالتطبيق (بما فيه
 * خدمة إمكانية الوصول وخدمة الكاميرا)، بيكتب نص الخطأ الكامل لملف محلي،
 * وبعدين يخلي النظام يتصرف بشكل طبيعي (يقفل العملية زي ما كان رح يصير أصلاً).
 *
 * الهدف: بدل ما الانهيار يضيع بالـ Logcat وحده (اللي المستخدم العادي ما
 * بيقدر يوصله)، بيصير عنا نسخة منه جوه ملف بالتطبيق نفسه، وMainActivity
 * بتعرضها أول ما التطبيق يرجع يفتح بعد الكراش.
 */
object CrashLogger {
    private const val FILE_NAME = "last_crash.txt"

    fun install(context: Context) {
        val appContext = context.applicationContext
        val existingHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                writeCrashLog(appContext, thread, throwable)
            } catch (_: Exception) {
                // ما في شي نعمله لو حتى كتابة اللوغ فشلت — بس ما لازم توقف
                // تسليم الاستثناء للمعالج الأصلي
            }
            existingHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun writeCrashLog(context: Context, thread: Thread, throwable: Throwable) {
        val sw = StringWriter()
        throwable.printStackTrace(PrintWriter(sw))
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val content = "الوقت: $timestamp\nالخيط: ${thread.name}\n\n${sw}"
        File(context.filesDir, FILE_NAME).writeText(content)
    }

    /** بترجع نص آخر كراش مسجّل، أو null لو ما فيه ولا واحد */
    fun readLastCrash(context: Context): String? {
        val file = File(context.applicationContext.filesDir, FILE_NAME)
        if (!file.exists()) return null
        return try {
            file.readText()
        } catch (_: Exception) {
            null
        }
    }

    fun clearLastCrash(context: Context) {
        val file = File(context.applicationContext.filesDir, FILE_NAME)
        if (file.exists()) file.delete()
    }
}

package com.gazescroller.app

import android.app.Application

class GazeApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // بنركّب ماسك الانهيارات هون عشان يشتغل قبل أي component تاني بالتطبيق
        // (Activity أو Service)، وهيك أي كراش بأي مكان بينلقط
        CrashLogger.install(this)
    }
}

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gazescroller.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.gazescroller.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // CameraX — لتشغيل الكاميرا الأمامية بكفاءة
    val cameraxVersion = "1.3.4"
    implementation("androidx.camera:camera-core:$cameraxVersion")
    implementation("androidx.camera:camera-camera2:$cameraxVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraxVersion")
    implementation("androidx.camera:camera-view:$cameraxVersion")

    // ML Kit — لكشف الوجه واتجاه ميل الرأس (بديل عملي وموثوق لتتبع العين الدقيق)
    implementation("com.google.mlkit:face-detection:16.1.7")

    // يسمح بتشغيل الكاميرا (اللي محتاجة LifecycleOwner) جوه Service شغّال بالخلفية
    implementation("androidx.lifecycle:lifecycle-service:2.8.3")
}
